using Microsoft.VisualStudio.TestTools.UnitTesting;
using ElectionGuard;
using System.Text.Json;
using System.Numerics;
using System.Collections.Generic;

namespace ElectionGuardWebAPIClientTests
{
    [TestClass]
    public class ElectionTest
    {
        private const string description = @"
{
    ""geopolitical_units"": [
        {
            ""object_id"": ""jefferson-county"",
            ""name"": ""Jefferson County"",
            ""type"": ""county"",
            ""contact_information"": {
                ""address_line"": [
                    ""1234 Samuel Adams Way"",
                    ""Jefferson, Hamilton 999999""
                ],
                ""name"": ""Jefferson County Clerk"",
                ""email"": [
                    {
                        ""annotation"": ""inquiries"",
                        ""value"": ""inquiries@jefferson.hamilton.state.gov""
                    }
                ],
                ""phone"": [
                    {
                        ""annotation"": ""domestic"",
                        ""value"": ""123-456-7890""
                    }
                ]
            }
        },
        {
            ""object_id"": ""harrison-township"",
            ""name"": ""Harrison Township"",
            ""type"": ""township"",
            ""contact_information"": {
                ""address_line"": [
                    ""1234 Thorton Drive"",
                    ""Harrison, Hamilton 999999""
                ],
                ""name"": ""Harrison Town Hall"",
                ""email"": [
                    {
                        ""annotation"": ""inquiries"",
                        ""value"": ""inquiries@harrison.hamilton.state.gov""
                    }
                ],
                ""phone"": [
                    {
                        ""annotation"": ""domestic"",
                        ""value"": ""123-456-7890""
                    }
                ]
            }
        },
        {
            ""object_id"": ""harrison-township-precinct-east"",
            ""name"": ""Harrison Township Precinct"",
            ""type"": ""township"",
            ""contact_information"": {
                ""address_line"": [
                    ""1234 Thorton Drive"",
                    ""Harrison, Hamilton 999999""
                ],
                ""name"": ""Harrison Town Hall"",
                ""email"": [
                    {
                        ""annotation"": ""inquiries"",
                        ""value"": ""inquiries@harrison.hamilton.state.gov""
                    }
                ],
                ""phone"": [
                    {
                        ""annotation"": ""domestic"",
                        ""value"": ""123-456-7890""
                    }
                ]
            }
        },
        {
            ""object_id"": ""rutledge-elementary"",
            ""name"": ""Rutledge Elementary School district"",
            ""type"": ""school"",
            ""contact_information"": {
                ""address_line"": [
                    ""1234 Wolcott Parkway"",
                    ""Harrison, Hamilton 999999""
                ],
                ""name"": ""Rutledge Elementary School"",
                ""email"": [
                    {
                        ""annotation"": ""inquiries"",
                        ""value"": ""inquiries@harrison.hamilton.state.gov""
                    }
                ],
                ""phone"": [
                    {
                        ""annotation"": ""domestic"",
                        ""value"": ""123-456-7890""
                    }
                ]
            }
        }
    ],
    ""parties"": [
        {
            ""object_id"": ""whig"",
            ""abbreviation"": ""WHI"",
            ""color"": ""AAAAAA"",
            ""logo_uri"": ""http://some/path/to/whig.svg"",
            ""name"": {
                ""text"": [
                    {
                        ""value"": ""Whig Party"",
                        ""language"": ""en""
                    }
                ]
            }
        },
        {
            ""object_id"": ""federalist"",
            ""abbreviation"": ""FED"",
            ""color"": ""CCCCCC"",
            ""logo_uri"": ""http://some/path/to/federalist.svg"",
            ""name"": {
                ""text"": [
                    {
                        ""value"": ""Federalist Party"",
                        ""language"": ""en""
                    }
                ]
            }
        },
        {
            ""object_id"": ""democratic-republican"",
            ""abbreviation"": ""DEMREP"",
            ""color"": ""EEEEEE"",
            ""logo_uri"": ""http://some/path/to/democratic-repulbican.svg"",
            ""name"": {
                ""text"": [
                    {
                        ""value"": ""Democratic Republican Party"",
                        ""language"": ""en""
                    }
                ]
            }
        }
    ],
    ""candidates"": [
        {
            ""object_id"": ""benjamin-franklin"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""Benjamin Franklin"",
                        ""language"": ""en""
                    }
                ]
            },
            ""party_id"": ""whig""
        },
        {
            ""object_id"": ""john-adams"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""John Adams"",
                        ""language"": ""en""
                    }
                ]
            },
            ""party_id"": ""federalist""
        },
        {
            ""object_id"": ""john-hancock"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""John Hancock"",
                        ""language"": ""en""
                    }
                ]
            },
            ""party_id"": ""democratic-republican""
        },
        {
            ""object_id"": ""write-in"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""Write In Candidate"",
                        ""language"": ""en""
                    },
                    {
                        ""value"": ""Escribir en la candidata"",
                        ""language"": ""es""
                    }
                ]
            },
            ""is_write_in"": true
        },
        {
            ""object_id"": ""referendum-pineapple-affirmative"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""Pineapple should be banned on pizza"",
                        ""language"": ""en""
                    }
                ]
            }
        },
        {
            ""object_id"": ""referendum-pineapple-negative"",
            ""ballot_name"": {
                ""text"": [
                    {
                        ""value"": ""Pineapple should not be banned on pizza"",
                        ""language"": ""en""
                    }
                ]
            }
        }
    ],
    ""contests"": [
        {
            ""@type"": ""CandidateContest"",
            ""object_id"": ""justice-supreme-court"",
            ""sequence_order"": 0,
            ""ballot_selections"": [
                {
                    ""object_id"": ""john-adams-selection"",
                    ""sequence_order"": 0,
                    ""candidate_id"": ""john-adams""
                },
                {
                    ""object_id"": ""benjamin-franklin-selection"",
                    ""sequence_order"": 1,
                    ""candidate_id"": ""benjamin-franklin""
                },
                {
                    ""object_id"": ""john-hancock-selection"",
                    ""sequence_order"": 2,
                    ""candidate_id"": ""john-hancock""
                },
                {
                    ""object_id"": ""write-in-selection"",
                    ""sequence_order"": 3,
                    ""candidate_id"": ""write-in""
                }
            ],
            ""ballot_title"": {
                ""text"": [
                    {
                        ""value"": ""Justice of the Supreme Court"",
                        ""language"": ""en""
                    },
                    {
                        ""value"": ""Juez de la corte suprema"",
                        ""language"": ""es""
                    }
                ]
            },
            ""ballot_subtitle"": {
                ""text"": [
                    {
                        ""value"": ""Please choose up to two candidates"",
                        ""language"": ""en""
                    },
                    {
                        ""value"": ""Uno"",
                        ""language"": ""es""
                    }
                ]
            },
            ""vote_variation"": ""n_of_m"",
            ""electoral_district_id"": ""jefferson-county"",
            ""name"": ""Justice of the Supreme Court"",
            ""primary_party_ids"": [
                ""whig"",
                ""federalist""
            ],
            ""number_elected"": 2,
            ""votes_allowed"": 2
        },
        {
            ""@type"": ""ReferendumContest"",
            ""object_id"": ""referendum-pineapple"",
            ""sequence_order"": 1,
            ""ballot_selections"": [
                {
                    ""object_id"": ""referendum-pineapple-affirmative-selection"",
                    ""sequence_order"": 0,
                    ""candidate_id"": ""referendum-pineapple-affirmative""
                },
                {
                    ""object_id"": ""referendum-pineapple-negative-selection"",
                    ""sequence_order"": 1,
                    ""candidate_id"": ""referendum-pineapple-negative""
                }
            ],
            ""ballot_title"": {
                ""text"": [
                    {
                        ""value"": ""Should pineapple be banned on pizza?"",
                        ""language"": ""en""
                    },
                    {
                        ""value"": ""�Deber�a prohibirse la pi�a en la pizza?"",
                        ""language"": ""es""
                    }
                ]
            },
            ""ballot_subtitle"": {
                ""text"": [
                    {
                        ""value"": ""The township considers this issue to be very important"",
                        ""language"": ""en""
                    },
                    {
                        ""value"": ""El municipio considera que esta cuesti�n es muy importante"",
                        ""language"": ""es""
                    }
                ]
            },
            ""vote_variation"": ""one_of_m"",
            ""electoral_district_id"": ""harrison-township"",
            ""name"": ""The Pineapple Question"",
            ""number_elected"": 1,
            ""votes_allowed"": 1
        }
    ],
    ""ballot_styles"": [
        {
            ""object_id"": ""jefferson-county-ballot-style"",
            ""geopolitical_unit_ids"": [
                ""jefferson-county""
            ]
        },
        {
            ""object_id"": ""harrison-township-ballot-style"",
            ""geopolitical_unit_ids"": [
                ""jefferson-county"",
                ""harrison-township""
            ]
        },
        {
            ""object_id"": ""harrison-township-precinct-east-ballot-style"",
            ""geopolitical_unit_ids"": [
                ""jefferson-county"",
                ""harrison-township"",
                ""harrison-township-precinct-east"",
                ""rutledge-elementary""
            ]
        },
        {
            ""object_id"": ""rutledge-elementary-ballot-style"",
            ""geopolitical_unit_ids"": [
                ""jefferson-county"",
                ""harrison-township"",
                ""rutledge-elementary""
            ]
        }
    ],
    ""name"": {
        ""text"": [
            {
                ""value"": ""Jefferson County Spring Primary"",
                ""language"": ""en""
            },
            {
                ""value"": ""Primaria de primavera del condado de Jefferson"",
                ""language"": ""es""
            }
        ]
    },
    ""contact_information"": {
        ""address_line"": [
            ""1234 Paul Revere Run"",
            ""Jefferson, Hamilton 999999""
        ],
        ""name"": ""Hamilton State Election Commission"",
        ""email"": [
            {
                ""annotation"": ""press"",
                ""value"": ""inquiries@hamilton.state.gov""
            },
            {
                ""annotation"": ""federal"",
                ""value"": ""commissioner@hamilton.state.gov""
            }
        ],
        ""phone"": [
            {
                ""annotation"": ""domestic"",
                ""value"": ""123-456-7890""
            },
            {
                ""annotation"": ""international"",
                ""value"": ""+1-123-456-7890""
            }
        ]
    },
    ""start_date"": ""2020-03-01T08:00:00-05:00"",
    ""end_date"": ""2020-03-01T20:00:00-05:00"",
    ""election_scope_id"": ""jefferson-county-primary"",
    ""type"": ""primary""
}";

        [TestMethod]
        public void ElectionContextTest()
        {
            var client = new MediatorClient("http://localhost:8000");
            var e = JsonSerializer.Deserialize<ElectionDescription>(description);
            var ec = new ElectionContextRequest();
            ec.description = e;
            ec.elgamal_public_key = "123455";
            ec.number_of_guardians = 5;
            ec.quorum = 3;
            var pc = client.ElectionContext(ec);
            pc.Wait();
            Assert.AreEqual(new BigInteger(123455), pc.Result.elgamal_public_key);
        }

        [TestMethod]
        public void TestGuardianCreation()
        {
            var guardianApi = new GuardianClient("http://localhost:8001");
            var mediatorApi = new MediatorClient("http://localhost:8000");
            var edesc = JsonSerializer.Deserialize<ElectionDescription>(description);
            var guardians = new string[] { "A B", "C D", "E F", "G H", "I J" };
            var glist = new List<Guardian>();
            for (var i = 0; i < guardians.Length; i++)
            {
                var g = guardianApi.Guardian(new GuardianRequest() { id = guardians[i], sequence_order = i, number_of_guardians = 5, quorum = 3 });
                g.Wait();
                glist.Add(g.Result);
            }
            var gpkeys = glist.ConvertAll(g => new ElectionPublicKey() { key = g.auxiliary_key_pair.public_key, proof g.auxiliary_key_pair.public_key });
            mediatorApi.ElectionCombine(new CombineElectionKeysRequest() { election_public_keys = gpkeys });
        }
    }
}
