$data = Import-Csv -Path .\CredenzialiOut.csv -Delimiter ';'
$data.Count

$roles = @('ASS', 'PA', 'PC', 'PO', 'RD', 'RU', 'TA')

$roles.Contains('ASS')

foreach ($d in $data | where { $roles.Contains($_.Role) }) {
#    Invoke-WebRequest -Uri 'https://api.adm.unipi.it:443/identitymanagement/v1.0/api/anagrafica/matricola/521762' -Headers { 'Authorization': 'Bearer a5b9ed49-ca1d-3db0-9652-1e671ea1a95c' }
    $d.cred = 'a' + $d.Mat.PadLeft(6, '0');
}

$data | Export-Csv -Path .\CredenzialiOut.csv -Delimiter ';'
$r = Invoke-WebRequest -Uri 'https://api.adm.unipi.it:443/identitymanagement/v1.0/api/anagrafica/matricola/521762' -Headers @{ 'Authorization'='Bearer a5b9ed49-ca1d-3db0-9652-1e671ea1a95c' }

($r.Content | ConvertFrom-Json).Cod_fiscale
"9217".PadLeft(6, '0')

$stud = Import-Csv .\MatStudenti.CSV -Delimiter ';'
$stud.Count

foreach ($s in $stud) {
    
}