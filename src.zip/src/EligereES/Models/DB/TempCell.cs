﻿using System;
using System.Collections.Generic;

namespace EligereES.Models.DB
{
    public partial class TempCell
    {
        public string Mat { get; set; }
        public string Cognome { get; set; }
        public string Cell { get; set; }
        public string Cellint { get; set; }
    }
}
